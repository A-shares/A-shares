// Package core 核心逻辑实现
package core
