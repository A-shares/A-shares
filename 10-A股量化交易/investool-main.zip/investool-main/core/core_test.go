package core

import "context"

var (
	_ctx = context.TODO()
)
