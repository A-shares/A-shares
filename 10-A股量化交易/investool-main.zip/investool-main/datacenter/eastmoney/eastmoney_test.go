package eastmoney

import (
	"context"
)

var (
	_em  = NewEastMoney()
	_ctx = context.TODO()
)
