package qq

import (
	"context"
)

var (
	_q   = NewQQ()
	_ctx = context.TODO()
)
