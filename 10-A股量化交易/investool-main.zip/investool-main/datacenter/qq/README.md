# qq

腾讯证券接口封装

https://stockapp.finance.qq.com/mstats/#

## 实现功能

- 关键词搜索
