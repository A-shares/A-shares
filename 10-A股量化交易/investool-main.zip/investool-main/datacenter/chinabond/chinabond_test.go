package chinabond

import (
	"context"
)

var (
	_c   = NewChinaBond()
	_ctx = context.TODO()
)
