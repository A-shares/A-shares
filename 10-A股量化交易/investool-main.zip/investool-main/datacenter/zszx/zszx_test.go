package zszx

import (
	"context"
)

var (
	_z   = NewZszx()
	_ctx = context.TODO()
)
