package sina

import (
	"context"
)

var (
	_s   = NewSina()
	_ctx = context.TODO()
)
