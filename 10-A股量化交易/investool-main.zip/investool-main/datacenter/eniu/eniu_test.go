package eniu

import (
	"context"
)

var (
	_e   = NewEniu()
	_ctx = context.TODO()
)
