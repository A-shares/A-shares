package cron

import "testing"

func TestSyncIndustryList(t *testing.T) {
	SyncIndustryList()
}
